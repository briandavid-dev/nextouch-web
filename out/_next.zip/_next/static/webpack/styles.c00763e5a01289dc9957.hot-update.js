webpackHotUpdate_N_E("styles",{

/***/ "./components/MenuDesktop/Menu.module.css":
false,

/***/ 3:
false

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9zdHlsZXMuYzAwNzYzZTVhMDEyODlkYzk5NTcuaG90LXVwZGF0ZS5qcyIsInNvdXJjZVJvb3QiOiIifQ==